from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView, DetailView, View
from django.http import HttpResponseRedirect
from django.urls import reverse


from .models import Post
from .forms import CommentForm



# Create your views here.

class StartingPageView(ListView):
    template_name = "blog/index.html"
    model = Post
    ordering = ["-date"]
    context_object_name = "posts"


    def get_queryset(self):
        queryset = super().get_queryset()
        data = queryset[:3]
        return data




class AllPostsView(ListView):
    template_name = "blog/all-post.html"
    model = Post
    ordering = ["-date"]
    context_object_name = "all_posts"



# class SinglePostView(DetailView):
#     template_name = "includes/post-detail.html"
#     model = Post

#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context["post_tags"] = self.object.tags.all()
#         context["comment_form"] = CommentForm()
#         # context["comments"] = post.comments.all()
#         return context



class SinglePostView(View):
    def is_stored_post(self, request, post_id):
        stored_posts = request.session.get("stored_posts")
        if stored_posts is not None:
            is_saved_for_later = post_id in stored_posts
        else:
            is_saved_for_later = False

        return is_saved_for_later


    def get(self, request, slug):
        post = Post.objects.get(slug=slug)

        context = {
            "post": post,
            "post_tags": post.tags.all(),
            "comment_form": CommentForm(),
            "comments": post.comments.all().order_by("-id"),
            "saved_for_later": self.is_stored_post(request, post.id)
        }
        return render(request,"includes/post-detail.html", context )
    

    def post(self, request, slug):
        comment_form = CommentForm(request.POST)
        post = Post.objects.get(slug=slug)

        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.post = post
            comment.save()

            return HttpResponseRedirect(reverse("post-detail-page", args=(slug,)))
        
        context = {
            "post": post,
            "post_tags": post.tags.all(),
            "comment_form": CommentForm(),
            "comments": post.comments.all().order_by("-id"),
            "saved_for_later": self.is_stored_post(request, post.id)
        }

        return render(request,"includes/post-detail.html", context )





class ReadLaterView(View):
    def get(self, request):
        stored_posts = request.session.get("stored_posts", [])

        context = {}

        if not stored_posts:
            context["posts"] = []
            context["has_posts"] = False
        else:
            posts = Post.objects.filter(id__in=stored_posts)
            context["posts"] = posts
            context["has_posts"] = True

        return render(request, "blog/stored_posts.html", context)


    def post(self, request):
        stored_posts = request.session.get("stored_posts", [])

        try:
            post_id = int(request.POST.get("post_id", ""))
        except (ValueError, TypeError):
            return HttpResponseRedirect(request.META.get("HTTP_REFERER", "/"))

        if post_id not in stored_posts:
            stored_posts.append(post_id)
            
        else:
            request.session["stored_posts"] = stored_posts
            
        return HttpResponseRedirect(request.META.get("HTTP_REFERER", "/"))






def contact_page(request):
    return render(request, "includes/contact.html", {"is_homepage": False})
